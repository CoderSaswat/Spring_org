package com.saswat.spring.springorm.product.dao;

import com.saswat.spring.springorm.product.entity.Product;

public interface ProductDao {
	int insert(Product product);
}
